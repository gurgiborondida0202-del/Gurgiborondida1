import os
import logging
import asyncio
from collections import defaultdict, deque

from dotenv import load_dotenv
from openai import OpenAI
from telegram import Update
from telegram.ext import (
    ApplicationBuilder,
    CommandHandler,
    MessageHandler,
    ContextTypes,
    filters,
)

load_dotenv()

TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "").strip()
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-5.5").strip()

if not TELEGRAM_BOT_TOKEN:
    raise RuntimeError("TELEGRAM_BOT_TOKEN дар файли .env гузошта нашудааст.")
if not OPENAI_API_KEY:
    raise RuntimeError("OPENAI_API_KEY дар файли .env гузошта нашудааст.")

client = OpenAI(api_key=OPENAI_API_KEY)
logging.basicConfig(
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger("gurgiborondida")

# Контексти кӯтоҳи ҳар гурӯҳ: барои идома додани суҳбат.
history = defaultdict(lambda: deque(maxlen=12))
# Барои пешгирӣ аз ҷавобҳои пайдарпайи аз ҳад зиёд.
busy_chats = set()

BOT_INSTRUCTIONS = """
Ту ёвари гурӯҳии Telegram ҳастӣ. Бо одамон дӯстона, гарм ва табиӣ суҳбат кун.
Асосан ба забони паём ҷавоб деҳ: тоҷикӣ, русӣ ё форсӣ.
Агар касе салом диҳад, бо саломи мувофиқ ҷавоб деҳ.
Ҷавобҳоро зинда, хушмуомила ва каме шавқовар навис; баъзан шӯхии безарар кун.
Ба маънои паём диққат деҳ ва суҳбатро бо як саволи кӯтоҳ идома дода метавонӣ.
Ҷавобҳоро одатан кӯтоҳ нигоҳ дор (1 то 4 ҷумла), аммо агар савол шарҳи зиёд талаб кунад,
равшантар фаҳмон.
Агар чизеро надонӣ, рост бигӯ; маълумот ё воқеаро насоз.
Ба таҳқир, ҷанҷол, таҳдид ва паёмҳои хатарнок ҳамроҳ нашав; оромона ҷавоб деҳ.
Ҳеҷ гоҳ худро одами воқеӣ вонамуд накун: агар пурсанд, бигӯ, ки ёвари зеҳни сунъӣ ҳастӣ.
Маълумоти махфӣ, рамзҳо, паролҳо ва кодҳои тасдиқро напурс.
"""

def ask_ai(chat_id: int) -> str:
    transcript = []
    for role, content in list(history[chat_id]):
        transcript.append(f"{role}: {content}")
    prompt = "\n".join(transcript)

    response = client.responses.create(
        model=OPENAI_MODEL,
        instructions=BOT_INSTRUCTIONS,
        input=prompt,
        max_output_tokens=220,
    )
    answer = (response.output_text or "").strip()
    return answer or "Бубахш, ҳоло ҷавоби дуруст пайдо карда натавонистам 🙂"

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.effective_message.reply_text(
        "Салом! Ман ёвари дӯстонаи GURGIBORONDIDA ҳастам 🤝\n"
        "Дар гурӯҳ паём нависед — ман ба суҳбат ҳамроҳ мешавам.\n"
        "Фармонҳо: /help"
    )

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.effective_message.reply_text(
        "Ман паёмҳои матнии гурӯҳро мехонам ва ба онҳо ҷавоб медиҳам.\n"
        "/start — оғоз\n/help — кӯмак\n"
        "Эзоҳ: ман боти зеҳни сунъӣ ҳастам."
    )

async def handle_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    message = update.effective_message
    chat = update.effective_chat
    user = update.effective_user

    if not message or not chat or not user or not message.text:
        return
    if user.is_bot:
        return
    if chat.id in busy_chats:
        return

    text = message.text.strip()
    if not text or text.startswith("/"):
        return

    # Дар гурӯҳ ва чати шахсӣ якхела кор мекунад.
    busy_chats.add(chat.id)
    try:
        name = user.first_name or "Дӯст"
        history[chat.id].append(("user", f"{name}: {text}"))

        answer = await asyncio.to_thread(ask_ai, chat.id)
        history[chat.id].append(("assistant", answer))

        # Telegram маҳдудияти дарозии паём дорад.
        if len(answer) > 4000:
            answer = answer[:3950] + "…"
        await message.reply_text(answer)
    except Exception:
        logger.exception("Хато ҳангоми коркарди паём")
        await message.reply_text(
            "Узр, ҳоло каме мушкили техникӣ шуд. Баъдтар боз навис 🙂"
        )
    finally:
        busy_chats.discard(chat.id)

async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE):
    logger.exception("Хатои коркард: %s", context.error)

def main():
    app = ApplicationBuilder().token(TELEGRAM_BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_command))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_text))
    app.add_error_handler(error_handler)

    logger.info("GURGIBORONDIDA бот оғоз шуд.")
    app.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == "__main__":
    main()
